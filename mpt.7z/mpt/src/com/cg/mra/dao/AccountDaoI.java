package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;

public interface AccountDaoI {

	public Account getAccountDetails(String mblNo);
	public int rechargeAccount(String mblNo, int rechargeAmount);
	public HashMap<String,Account> accountEntry();

}
