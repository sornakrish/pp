package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountServiceI {
	public Account getAccountDetails(String mblNo);
	public int rechargeAccount(String mblNo, int rechargeAmount);

}
