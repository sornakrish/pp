package com.capgemini.hotel.bean;

public class RoomBooking {
	private int bookingId;
	private int customerId;
	private int roomNo;
	private String roomType;
	
	//generate getters and setters 
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public RoomBooking(int roomNo, String roomType) {
		super();
		this.roomNo = roomNo;
		this.roomType = roomType;
	}
	
	

}
