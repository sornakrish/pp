package com.capgemini.hotel.dao;

import java.util.HashMap;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.ui.Client;

public class CustomerBookingDAO implements ICustomerBookingDAO {
	CustomerBean beanObj;
	RoomBooking rmObj;
	Client c;

	//hashmap for customer deatils
	HashMap<Integer,CustomerBean> hm1=new HashMap<Integer,CustomerBean>();
	//hashmap for booking details
	HashMap<Integer,RoomBooking> hm2=new HashMap<Integer,RoomBooking>();
	
	
	
	
	/*public CustomerBookingDAO() {
		super();
		
		hm2.put(beanObj.getCustomerId(),new RoomBooking(101,"AC-single"));
		hm2.put(beanObj.getCustomerId(),new RoomBooking(102,"AC-single"));
		hm2.put(beanObj.getCustomerId(),new RoomBooking(103,"AC-double"));
		hm2.put(beanObj.getCustomerId(),new RoomBooking(101,"NONAC-single"));
		hm2.put(beanObj.getCustomerId(),new RoomBooking(101,"NONAC-single"));
		hm2.put(beanObj.getCustomerId(),new RoomBooking(101,"AC-double"));
		
	} */
	
	public void addCustomerDetails(CustomerBean obj1) {
		hm1.put(obj1.getCustomerId(),obj1);
		 hm1.get(beanObj.getCustomerId());
		 System.out.println(hm1);
		 }
	
		
		
		
	
	public HashMap<Integer,CustomerBean> hm1()
	{
		return hm1;
	}
	public HashMap<Integer,RoomBooking> hm2()
	{
		return hm2;
	}
	
	
	public RoomBooking getBookingDetails(int customerId1) {
		RoomBooking det = hm2.get(customerId1);
		
		if(hm2.containsKey(det))
		{
			System.out.println("Name of the customer"+beanObj.getName());
			System.out.println("Room No"+rmObj.getRoomNo());
			System.out.println("Room type"+rmObj.getRoomType());
			
		}
		return det;
		
		
	}
	

}
