package com.capgemini.hotel.dao;

import java.util.HashMap;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public interface ICustomerBookingDAO {
	public void addCustomerDetails(CustomerBean obj1);
	public HashMap<Integer,CustomerBean> hm1();
	public RoomBooking getBookingDetails(int customerId1);

}
