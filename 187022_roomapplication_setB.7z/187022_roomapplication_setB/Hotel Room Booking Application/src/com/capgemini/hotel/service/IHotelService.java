package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public interface IHotelService {
	public void addCustomerDetails(CustomerBean obj1);
	public void getBookingDetails(int customerId1);

}
