package com.capgemini.hotel.service;

import java.util.HashMap;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;

public class HotelService implements IHotelService {
	CustomerBookingDAO daoObj = new CustomerBookingDAO();

	public void addCustomerDetails(CustomerBean obj1) {
		daoObj.addCustomerDetails(obj1);
	}

	public void getBookingDetails(int customerId1) {
		daoObj.getBookingDetails(customerId1);

	}

}
