package com.capgemini.hotel.ui;

import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.service.HotelService;

public class Client {
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		HotelService Obj = new HotelService();
		Scanner scan = new Scanner(System.in);
		int ch;
     
		do {
			//to get users choice
			
			System.out.println("1) Book Room \n2) View Booking Details \n3)Exit \n");
			System.out.println("Enter Your Choice : ");
			ch = scan.nextInt();

			switch (ch) {
			case 1:           //to book room
				System.out.println("Enter Customer Name : ");
				String name = nameCheck(scan.next());
				System.out.println("Enter Email : ");
				String email = scan.next();
				System.out.println("Enter Customer Address : ");
				String address = scan.next();
				System.out.println("Enter Mobile No : ");
				String mobileNo = mobileCheck(scan.next());
				System.out.println("Room No : ");
				int roomNo = scan.nextInt();
				System.out.println("Room Type : ");
				String roomType = scan.next();
				Random r = new Random();
				int customerId = r.nextInt(2000);

				RoomBooking Obj2 = new RoomBooking(roomNo, roomType);
				CustomerBean Obj1 = new CustomerBean(name, email, address, mobileNo, customerId, Obj2);

				Obj.addCustomerDetails(Obj1);

				System.out.println("Room is booked successfully with the customer id" + customerId);
				System.out.println("Your name: " + name);
				System.out.println("Your mobile number: " + mobileNo);
				System.out.println("Your room number: " + roomNo);
				System.out.println("Your room type: " + roomType);

				break;

			case 2:    //view booking details
				System.out.println("Enter Customer Id : ");
				int customerId1 = scan.nextInt();

				Obj.getBookingDetails(customerId1);

				break;

			case 3:     //exit
				System.exit(0);

			}

		} while (ch < 4);
	}

	public static String nameCheck(String name) {
		while (true) {
			if (Pattern.matches("([A-Z])*([a-z])*", name)) {
				return name;
			} else {
				System.out.println("Name should only have alphabets.");
				System.out.println("Enter again: ");
				name = scan.next();
			}
		}
	}

	public static String mobileCheck(String mobileNo) {
		while (true) {
			if (String.valueOf(mobileNo).length() < 10) {
				System.out.println("Enter valid mobile number.");

				mobileNo = scan.next();
			} else {
				return mobileNo;
			}
		}

	}
}
